<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
<style type="text/css">
    hr.style{
    overflow: visible; /* For IE */
    width: 620px;
    margin-top: 0px ;
    border: none;
    border-top: medium double #333;
    color: #333;
    text-align: center;
}
hr.style2{
    overflow: visible; /* For IE */
    width: 130px;
    margin-top: 0px ;
    border: none;
    color: #333;
    border-top: medium double #333;
    text-align: center;
}

</style>  
</head>
  <body>
  <table align="center">
        <tr>
            <td align="center">
                <font size="4">PUSKESMAS CIMAHI UTARA</font><br>
                <small> Jln.Jati Serut No.16 Kec.Cimahi Utara, Kota Cimahi, Jawa Barat 40767</small><br>
                <strong> LAPORAN PEMINJAMAN BERKAS REKAM MEDIS PASIEN POLI GIGI </strong>
            </td>
        </tr>
    </table><br>
        <table align="center">
        <tr>
            <td ><hr class="style"></td>
        </tr>
        </table>
       
    </table>
   
    <br>
    
    <table align="center">
        <tr>
            <td>
                <font size="2">Nomor Rekam Medis
            </td>
            <td width="350px"> : <?php echo e($peminjaman->no_rm); ?></td>
        </tr>
        <tr>
            <td>
                <font size="2">Nama Pasien
            </td>
            <td width="350px"> : <?php echo e($peminjaman->nama_pasien); ?></td>
        </tr>
        <tr>
            <td>
                <font size="2">Diagnosa
            </td>
            <td width="350px"> : <?php echo e($peminjaman->diagnosa); ?></td>
        </tr>
        <tr>
            <td>
                <font size="2">Tindakan
            </td>
            <td width="350px"> : <?php echo e($peminjaman->tindakan); ?></td>
        </tr>
        <tr>
            <td>
                <font size="2">Tanggal Berobat
            </td>
            <td width="350px">
                <font size="2"> : <?php echo e($peminjaman->tanggal_berobat); ?>

            </td>
        </tr>
        <tr>
            <td>
                <font size="2">Tanggal Peminjaman Berkas
            </td>
            <td width="350px">
                <font size="2"> : <?php echo e($peminjaman->tanggal_pinjam); ?></td>
        </tr>

    </table>
    <br>
    
    <br>
   
    <br>
    <table align="center">
        <tr>
            <td width="400px"> </td>
            <td><font size="2">Cimahi Utara, <?php echo e($date); ?></td>
        </tr>
       
    </table>
        <table align="center">
        <tr>
            <td><font size="2">Dokter Peminjam</td>
            <td width="300px"> </td>
            <td><font size="2">Petugas</td>
                
        </tr>
    </table>
    <br><br> <br><br> 
    <table align="center">
        <tr>
            <td align="center"><?php echo e($peminjaman->nama_dokter); ?></td>
            <td width="300px"> </td>
            <td align="center"><?php echo e($peminjaman->nama_petugas); ?></td>
                
        </tr>
    </table>
    
    
</body>
</html><?php /**PATH C:\xampp\htdocs\Peminjaman_rm\resources\views/peminjaman/peminjaman_pdf.blade.php ENDPATH**/ ?>