
<?php $__env->startSection('content'); ?>
<section class="content">

    <div class="row">
        <div class="col-12">
          
         
                <form >
                    <div class="form-row">
                        <div class="col-5">
                        <select name="date" class="custom-select my-1 mr-sm-2" id="inlineFormCustomSelectPref">
                                <option selected disabled>Date</option>
                                <?php $__currentLoopData = App\Peminjaman::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->tanggal_pinjam); ?>"><?php echo e($row->tanggal_pinjam); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                            
                        </div>
                        <table class="sebaran table table-bordered table table-striped table-responsive" id="sebaran">
                        <thead>
                            <tr class="text-center">
                                <th>No</th>
                                <th>Kode Rm</th>
                                <th>Nama Pasien</th>
                                <th>Diagnosa</th>
                                <th>Tindakan</th>
                                <th>Tanggal Berobat</th>
                                <th>Nama Dokter</th>
                                <th>Nama Petugas</th>
                                <th>Tanggal Pinjam</th>

                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no=1;?>
                            <?php $__currentLoopData = $peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center">
                                <td><?php echo e($no++); ?> </td>
                                <td><?php echo e($row->no_rm); ?></td>
                                <td><?php echo e($row->nama_pasien); ?></td>
                                <td><?php echo e($row->diagnosa); ?></td>
                                <td><?php echo e($row->tindakan); ?></td>
                                <td><?php echo e($row->tanggal_berobat); ?></td>
                                <td><?php echo e($row->nama_dokter); ?></td>
                                <td><?php echo e($row->nama_petugas); ?></td>
                                <td><?php echo e($row->tanggal_pinjam); ?></td>

                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                       
                        
                        <button type="submit" class="btn btn-primary mb-2">View</button>
                    </div>
                </form>
            
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Peminjaman_rm\resources\views/laporan/peminjaman.blade.php ENDPATH**/ ?>