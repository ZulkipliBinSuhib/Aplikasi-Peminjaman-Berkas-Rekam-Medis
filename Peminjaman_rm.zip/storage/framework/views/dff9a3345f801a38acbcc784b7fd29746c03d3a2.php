
<?php $__env->startSection('content'); ?>
<div class="col-md-12 col-lg-12 bg-info">
    <div class="text-center text-light ">
      <br>
       <h3>HALAMAN UTAMA</h3>
       <br>
    </div>
</div>

<div class="col-md-12 col-lg-12 bg-info">
    <div class="card-service text-center text-lg-left mb-4 ">
       
        <h5 class="card-service__subtitle">Aplikasi Peminjaman Berkas Rekam Medis adalah Sistem Informasi Berbasis Web yang berfungsi mengelola Data Peminjaman Berkas Rekam Medis Puskesmas Cimahi Utara.</h5>
    </div>
  </div>
  <div class="col-md-12 col-lg-12 bg-info">
    <div class="card-service text-center text-lg-left mb-4 ">
       
        <h5 class="card-service__subtitle" >Dokter bisa melakukan Peminjaman Berkas Pasien kepada petugas Rekam Medis dan Petugas Rekam Medis akan melakukan pencatatan Peminjaman Berkas ke dalam Sistem yang dikomputerisasi berbasis web.</h5>
    </div>
  </div><div class="col-md-12 col-lg-12 bg-info">
    <div class="card-service text-center text-lg-left mb-4 ">
       
        <h5 class="card-service__subtitle">Sistem ini bertugas menginput semua data pasien yang berobat di Puskesmas Cimahi Utara dan menginput berkas Rekam Medis di Puskesmas yan dipinjam Dokter kepada Petugas Rekam Medis.</h5>
    </div>
  </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Peminjaman_rm\resources\views/pageDashboard.blade.php ENDPATH**/ ?>